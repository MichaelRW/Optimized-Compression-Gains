clear all;
mex -v model_IHC_BEZ2018.c complex.c  
clear all;
mex -v model_Synapse_BEZ2018.c complex.c 
