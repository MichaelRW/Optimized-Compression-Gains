%speech_gains2a( 'ehhrtf_1p7k_100k', 65, [-25 25], 5, 'DSL', 40, 'IHCL', 10e-6 );
%speech_gains2a( 'ehhrtf_1p7k_100k', 65, [-25 25], 5, 'DSL', 40, 'OHCL', 10e-6 );
speech_gains2a( 'ehhrtf_1p7k_100k', 65, [-25 25], 5, 'DSL', 40, 'Mixed', 10e-6 );

%speech_gains2a( 'ehhrtf_1p7k_100k', 65, [-25 25], 5, 'DSL', 40, 'IHCL', 80e-6 );
%speech_gains2a( 'ehhrtf_1p7k_100k', 65, [-25 25], 5, 'DSL', 40, 'OHCL', 80e-6 );
%speech_gains2a( 'ehhrtf_1p7k_100k', 65, [-25 25], 5, 'DSL', 40, 'Mixed', 80e-6 );